
<?php
//writing cleaning function 
function cleanInput($param){
   $data = trim($param);// value of the fname filed in form will be stored in the $name
    $data = strip_tags($data);//remove the tags if available
    $data = htmlspecialchars($data);//change the meaningfull html charatcters like < > " ' to special characters

    return $data;
}
?>