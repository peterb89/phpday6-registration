<?php
require_once "function.php";
$error = false;
if(isset($_POST['register'])){//check if the rgister button clicked and the "register" key has set
    $fname = cleanInput($_POST['fname']);//called the cleanInput function and get the clean data and stored inside the $fname
    $lname = cleanInput($_POST['lname']);
    $email = cleanInput($_POST['email']);
    $password = cleanInput($_POST['password']);

    //echo $fname;
    //first name validation
    if(empty($fname)){
        $error = true;
        $fnameError = "The First Name is mandatory";
    }elseif(strlen($fname) < 3 || strlen($fname) > 30){
        $error = true;
        $fnameError = "The First Name should be between 3 and 30 characters";
    }elseif(!preg_match("/^[a-zA-Z\s]+$/", $fname)){
        $error = true;
        $fnameError = "You are allowed just to use small and capital letter as well as space";
    }

    //last name validation
    if(empty($lname)){
        $error = true;
        $lnameError = "The Last Name is mandatory";
    }elseif(strlen($lname) < 3 || strlen($lname) > 30){
        $error = true;
        $lnameError = "The Last Name should be between 3 and 30 characters";
    }elseif(!preg_match("/^[a-zA-Z\s]+$/", $lname)){
        $error = true;
        $lnameError = "You are allowed just to use small and capital letter as well as space";
    }

    //password validation
    if(empty($password)){
        $error = true;
        $passwordError = "The Password is mandatory";
    }elseif(!preg_match("/^(?=.*[A-Za-z])(?=.*\d).{6,}$/", $password)){
        $error = true;
        $passwordError = "Password must contain at least one letter, one number, and be at least 6 characters long";
}

    //email validation
    if(empty($email)){
        $error = true;
        $emailError = "The Email is mandatory";
    }elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = true;
        $emailError = "Please enter a valid email address";
    }
    }

    
    //image validation
   if(isset($_FILES["picture"]) && $_FILES["picture"]["error"] == 4){
    $error = true;
    $pictureError = "You must upload an image";
   } 


    if(!$error){
        echo "You will never see this message if the $error is true";
        //send data to the table
    }
    
        


?> 

 


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <div class="container mt-5">
        <div class="row">
        <h1 class="mb-4">User Registration</h1>
    </div>


<div class="row">

 <form method="post" enctype="multipart/form-data">
  <div class="mb-3">

<div class="mb-3">
    <label for="fname" class="form-label">First Name *</label>
    <input type="text" class="form-control" id="fname" name="fname" value="<?= $fname ?? "" ?>">
    <p class="text text-danger"><?= $fnameError ?? "" ?></p>
</div>
<div class="mb-3">
    <label for="lname" class="form-label">Last Name *</label>
    <input type="text" class="form-control" id="lname" name="lname" value="<?= $lname ?? "" ?>">
    <p class="text text-danger"><?= $lnameError ?? "" ?></p>

</div>

    <label for="exampleInputEmail1" class="form-label">Email address *</label>
    <input type="email" class="form-control" id="exampleInputEmail1" name="email" value="<?= $email ?? "" ?>" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password *</label>
    <input type="password" class="form-control" id="exampleInputPassword1" name="password">
    <p class="text text-danger"><?= $passwordError ?? "" ?></p>
  </div>
<div class="mb-3">
    <label for="picture" class="form-label">Upload Your Profile Image</label>
    <input type="file" class="form-control" id="picture" name="picture">
    <p class="text text-danger"><?= $pictureError ?? "" ?></p>

</div>

  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">I agree to the terms and conditions *</label>
  </div>
  <button type="submit" class="btn btn-primary" name="register">Register</button>
</form>
</div>

    </div>

</body>
</html>
